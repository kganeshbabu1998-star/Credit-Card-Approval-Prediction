# Drop Duplicate Features

## Objective
Remove duplicate records from the Credit Card Approval Prediction dataset.

## Tools Used
- Python
- Google Colab
- Pandas

## Files
- Drop_Duplicate_Features.ipynb

## Description
Loaded the datasets, identified duplicate records, removed them using Pandas `drop_duplicates()`, verified the results, and saved the cleaned datasets.