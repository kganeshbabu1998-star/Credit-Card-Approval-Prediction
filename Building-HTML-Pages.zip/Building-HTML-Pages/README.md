\# Building HTML Pages



\## Project

Credit Card Approval Prediction



\## Description

This task includes the frontend HTML pages for the Credit Card Approval Prediction application.



\## Files Included



\- home.html

\- index.html

\- result.html

\- style.css



\## Folder Structure



Building-HTML-Pages/

│

├── templates/

│   ├── home.html

│   ├── index.html

│   └── result.html

│

├── static/

│   └── style.css

│

└── README.md



\## Technologies Used



\- HTML5

\- CSS3



\## Note



These HTML pages are designed to be integrated with a Flask backend in the complete application.

