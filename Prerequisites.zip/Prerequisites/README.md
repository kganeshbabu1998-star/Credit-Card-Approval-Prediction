# Prerequisites

## Project
Credit Card Approval Prediction

## Software Used

- Anaconda Navigator
- PyCharm

## Python Libraries

- NumPy
- Pandas
- Scikit-learn
- Matplotlib
- Seaborn
- Flask

## Description

These tools and libraries are required for data preprocessing, machine learning model development, visualization, and deployment of the Credit Card Approval Prediction project.